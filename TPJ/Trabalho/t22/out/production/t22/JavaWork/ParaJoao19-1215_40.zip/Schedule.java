package JavaWork;

abstract class Schedule {
    
    public abstract void scheduleClass();

}
