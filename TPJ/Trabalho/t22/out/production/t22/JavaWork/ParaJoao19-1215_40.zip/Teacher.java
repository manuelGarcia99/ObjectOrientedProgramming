package JavaWork;

public class Teacher extends User{
    Teacher(){
        super("");
    }
}
