package JavaWork;

import java.util.ArrayList;
import java.util.HashMap;

public class Weekday extends Schedule {
    HashMap<Integer, Boolean> morning;
    HashMap<Integer, Boolean> evening;

    ArrayList<Class> classList;

    Weekday() {
        morning = new HashMap<Integer, Boolean>();
        morning.put(8, false);
        morning.put(9, false);
        morning.put(10, false);
        morning.put(11, false);

        evening = new HashMap<Integer, Boolean>();
        evening.put(14, false);
        evening.put(15, false);
        evening.put(16, false);
        evening.put(17, false);
        evening.put(18, false);

        classList = new ArrayList<Class>();
    }

    public void scheduleClass() {
        System.out.println("1- Morning");
        System.out.println("2- Evening");
        int answer = Ler.umInt();
        if(answer == 1) {
            
        } else if(answer == 2) {

        } else {
            System.out.println("Invalid Input");
            scheduleClass();
        }
    }

   /* public int askHour() {
        ArrayList<> freeClasses= 
        for(int i=0; i<classList.size(); i++) {
            if(!classList.get(i).isFull()) {
                // ID of classes that are free
                classList.get(i).getId();
                classList.get(i).getHour;
            }
        }
        for(int j=0; j<freeClasses.size(); j++) {
            System.out.printf();
        }
        System.out.println();
    }*/
}

/*
 * startMorning = 8
 * endMorning = 12
 * startEvening = 14
 * endEvening = 19
 */
