package JavaWork;

public class Weekend {
    
}
