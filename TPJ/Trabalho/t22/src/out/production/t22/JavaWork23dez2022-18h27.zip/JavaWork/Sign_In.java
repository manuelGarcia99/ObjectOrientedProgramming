package JavaWork;
import java.util.*;
import java.io.*;

public class Sign_In {

    public static void askUserOrAdm(ArrayList<User> myUsers) {
        System.out.println("1- User");
        System.out.println("2- Administrator");
        System.out.println("3- Go back");
        int answer = Ler.umInt();
        if(answer == 1) {
            insertUser(myUsers);
        } else if(answer == 2) {

        } else if(answer == 3) {
            
        } else {
            System.out.println("Invalid Input");
            askUserOrAdm(myUsers);
        }
    }

    public static void insertTeacher(ArrayList<Teacher> teachers) {
        System.out.println("What is your name? ");
        String name = Ler.umaString();
        Teacher l = new Teacher(name);
        teachers.add(l);
        try {
            ObjectOutputStream os = new ObjectOutputStream(new FileOutputStream("C:\\Users\\Lenovo\\Desktop\\JavaWork\\Teacher.dat"));
            os.writeInt(Teacher.getLast());
            os.writeObject(teachers);
            os.flush();
        } catch(IOException e) {
            System.out.println(e.getMessage());
        }
    }

    public static void insertUser(ArrayList<User> users) {
        System.out.println("What is your name? ");
        String name = Ler.umaString();
        User l = new User(name);
        users.add(l);
        try {
            ObjectOutputStream os = new ObjectOutputStream(new FileOutputStream("C:\\Users\\Lenovo\\Desktop\\JavaWork\\User.dat"));
            os.writeInt(User.getLast());
            os.writeObject(users);
            os.flush();
        } catch(IOException e) {
            System.out.println(e.getMessage());
        }
    }

    public static boolean checkPin(String pin) {
        boolean allDigits = false;
        if (pin.length() != 5) {
            System.out.println("You have not entered a 5-digit pin");
        } else {
            allDigits = true;
            for (int i = 0; i < 4; i++) {
                if (!Character.isDigit(pin.charAt(i))) {
                    allDigits = false;
                    break; // break gets you out of the for cycle
                }
            }
        }
        if (allDigits) {
            return true;
        } else {
            System.out.println("Enter a number");
            return false;
        }
    }
}
