package JavaWork;

import java.io.*;
import java.util.ArrayList;

public class Login {

    public static void enterID(ArrayList<User> mUsers) {
        int answer = -1;
        do {
            answer = enterIDPrompt();
            if (answer != 0) {
                loginUser(mUsers, answer);
            }
        } while (answer != 0);
    }

    public static int enterIDPrompt() {
        // nobody has ID = 0, that's why it's reserved for "Cancel"
        System.out.println("0- Cancel");
        System.out.println("Enter ID: ");
        int answer = Ler.umInt();
        return answer;
    }

    public static void loginUser(ArrayList<User> users, int id) {
        boolean found = false;
        // guess from 0 to 9999 (guess has to be String, so 64 doesn't work, and you have
        // to type 0064 instead)
        for (int i = 0; i < users.size(); i++) {
            if (users.get(i).getId() == id) {
                found = true;
                String password = users.get(i).getPassword();
                //after the user misses the guess three times, it comes back
                guess(3, password, id, users);
            }
        }
        if (!found) {
            System.out.println("There is no User with that ID");

        } else {
          enterID(users);
        }
    }

    public static void guess(int maxGuesses, String password, int id, ArrayList<User> users) {
        String guess;
        int guessCount = 0;
        boolean outOfGuesses = false;
        /*
         * "guess == password" doesn't work because it only works for numbers.
         * For Strings, you must use "guess.equals(password)"
         */
        while (!outOfGuesses && guessCount < maxGuesses) {
            System.out.print("Enter password: ");
            guess = Ler.umaString();
            guessCount++;
            if (guess.equals(password))
                outOfGuesses = true;
        }
        if (outOfGuesses == true) {
            // o guess corresponde a password
            menuUser(users, id);
        } else {
            System.out.println("Try again");
        }
    }

    /*
     * ArrayList User
     * 0 1 2 = users.get(i)
     * User1, User2, User3
     * 1 2 3 = id
     * 
     * Delete User2
     * 
     * ArrayList User
     * 0 1 = users.get(i)
     * User1, User3
     * 1 3 = id
     */

    public static void menuUser(ArrayList<User> users, int id) {
        System.out.println("0- Logout");
        System.out.println("1- Check information");
        System.out.println("2- Check classes");
        int answer = Ler.umInt();
        do {
            if (answer == 1) {
                for (int i = 0; i < users.size(); i++) {
                    if (users.get(i).getId() == id) {
                        System.out.println(users.get(i));
                    }
                }
            } else if (answer == 2) {

            }
        } while( answer != 0);
    }

    public static void deleteUser(ArrayList<User> users) {
        System.out.println("What is the ID of the User? ");
        int id = Ler.umInt();
        for (int i = 0; i < users.size(); i++) {
            if (users.get(i).getId() == id) {
                users.remove(users.get(i));
            } else {
                System.out.println("There is no User with that ID");
            }
        }
        try {
            ObjectOutputStream os = new ObjectOutputStream(
                    new FileOutputStream("C:\\Users\\Lenovo\\Desktop\\v1.1\\User.dat"));
            os.writeObject(users);
            os.flush();
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }

}

// class User
// class Teacher extends User