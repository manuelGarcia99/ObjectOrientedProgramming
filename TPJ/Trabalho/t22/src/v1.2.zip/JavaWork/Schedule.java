package JavaWork;

abstract class Schedule {
    
    public abstract void scheduleClass(Class c);

}
