package JavaWork;

import java.io.*;
import java.util.ArrayList;

/*
 * Login (User(People or Teacher) or Administrator)
 * Sign in (only User(People or Teacher))
 * 
 * Users can change their passwords
 * Teacher can see everything in it's Users data, except passwords
 * Administrator can see everything (User(People or Teacher) data)
 * 
 * In Sign in, Users choose their name, telefone, ... and create password
 * Be able to change passwords
 * 
 * User(People and Teachers) can change their own passwords and see their data
 * Teachers see Students of their classes data (except passwords)
 * 
 * Administrators can see everyones data (not including passwords) and create
 * classes and give Teacher priviledges to a User
 * 
 * Users can be 'People' or Teachers
 * 
 * (1.0) 1- Login
 * (2.0) 2- Sign in
 * 
 * If you choose 1:
 * (1.1) 1- Adminitrator (default name and password until you change it)
 * (Pretending there are already Administrator id=1
 * and Adminstrator id=2, ...
 * (By default, your id is "3" and your
 * default password is "0000", please change it)
 * (1.2) 2- User
 * 
 * (1.1.1) Insert your ID:
 * (1.1.1.1) Insert password:
 * (1.1.1.1.1) 1- See Users (People and Teachers)
 * 2- Make a User become a Teacher
 * 3- See Teachers
 * 4- Create classes
 * 
 * (1.2.1) Insert your ID:
 * (1.2.1.1) Insert password:
 * 
 * Users[1, 2, 3(Teacher), 4, 5(Teacher)]
 * Teacher[3(Teacher), 5(Teacher)]
 */

public class Main {

    public static void main(String[] args) {

        ArrayList<User> myUsers = new ArrayList<>();
        try {
            ObjectInputStream isUser = new ObjectInputStream(new FileInputStream(
                    "C:\\Users\\Lenovo\\Desktop\\v1.1\\User.dat"));
            int last = isUser.readInt();
            User.setLast(last);
            myUsers = (ArrayList<User>) isUser.readObject();
        } catch (IOException e) {
            System.out.println(e.getMessage());
        } catch (ClassNotFoundException e) {
            System.out.println(e.getMessage());
        }

        mainMenu(myUsers);

    }

    public static void mainMenu(ArrayList<User> myUsers) {
        int answer = -1;
        do {
            answer = mainMenuPrompt();
            if (answer == 1) {
                loginMenu(myUsers);
            } else if (answer == 2) {
                signInMenu(myUsers);
                System.out.println("Still not implemented");
            } else if(answer != 0){
                System.out.println("Invalid input, please try again.");
                mainMenu(myUsers);
            }
        } while (answer != 0);
        System.out.println("Leaving program...");
    }

    public static int mainMenuPrompt() {
        int answer;
        System.out.println("\n\nYou are on the Main Menu:");
        System.out.println("0- Leave");
        System.out.println("1- Login");
        System.out.println("2- Sign in");
        answer = Ler.umInt();
        return answer;
    }

    public static void loginMenu(ArrayList<User> myUsers) {
        int answer = -1;
        do {
            answer = loginMenuPrompt();
            if(answer ==1) {
                Login.enterID(myUsers);
            } else if(answer == 2) {
                System.out.println("Still not implemented");
            } else if(answer!=0) {
                System.out.println("Invalid input, please try again.");
                loginMenu(myUsers);
            }
        } while(answer!=0);
    }

    public static int loginMenuPrompt() {
        System.out.println("\n\nYou are on the login menu");
        System.out.println("0- Cancel");
        System.out.println("1- User");
        System.out.println("2- Administrator");
        int answer = Ler.umInt();
        return answer;
    }

    public static void signInMenu(ArrayList<User> myUsers) {
        int answer = -1;
        do {
            answer = signInMenuPrompt();
            if(answer == 1) {
                Sign_In.insertUser(myUsers);
            } else if(answer == 2) {

            } else if(answer != 0) {
                System.out.println("Invalid input, please try again.");
                signInMenu(myUsers);
            }
        } while( answer != 0);
    }

    public static int signInMenuPrompt() {
        System.out.println("\n\nYou are on the sign-in menu");
        System.out.println("0- Cancel");
        System.out.println("1- User");
        System.out.println("2- Administrator");
        int answer = Ler.umInt();
        return answer;
    }

    

}
