package JavaWork;

import java.util.ArrayList;
import java.io.*;

public class User implements Serializable {
    private int id;
    private String name;
    private String password;
    private ArrayList<Class> assignedClasses;
    private static int last = 0;
    public User(String name, String password) {
        last++;
        id = last;
        this.name = name;
        this.password = password;
        assignedClasses = new ArrayList<Class>();
    }

    public int getId() {
        return id;
    }

    public static void setLast(int last) {
        User.last = last;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public String toString() {
        return "\nUser{" + "id=" + id + ", name=" + name + "}";
    }

    public static int getLast() {
        return last;
    }

    public boolean equals(Object obj) {
        if (obj != null && this.getClass() == obj.getClass()) {
            User e = (User) obj;
            return (this.id == e.id && this.name.equals(e.name));
        }
        return false;
    }

    public Object clone() {
        User copy = new User(name,password);
        return copy;
    }
}
