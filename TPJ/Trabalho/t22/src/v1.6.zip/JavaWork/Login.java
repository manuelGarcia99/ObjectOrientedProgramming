package JavaWork;

import java.io.*;
import java.util.ArrayList;

public class Login {










    /*
     * ArrayList User
     * 0 1 2 = users.get(i)
     * User1, User2, User3
     * 1 2 3 = id
     * 
     * Delete User2
     * 
     * ArrayList User
     * 0 1 = users.get(i)
     * User1, User3
     * 1 3 = id
     */


    public static void deleteUser(ArrayList<User> users) {
        System.out.println("What is the ID of the User? ");
        int id = Ler.umInt();
        for (int i = 0; i < users.size(); i++) {
            if (users.get(i).getId() == id) {
                users.remove(users.get(i));
            } else {
                System.out.println("There is no User with that ID");
            }
        }
        try {
            ObjectOutputStream os = new ObjectOutputStream(
                    new FileOutputStream("C:\\Users\\Lenovo\\Desktop\\v1.1\\User.dat"));
            os.writeObject(users);
            os.flush();
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }

}

// class User
// class Teacher extends User