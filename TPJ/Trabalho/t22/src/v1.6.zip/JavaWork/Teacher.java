package JavaWork;

import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;

public class Teacher extends User {
    private ArrayList<Class> teachClassList; // list of classes that the teacher teaches

    @Override
    public String toString() {
        return "Teacher{" +
                "teachClassList=" + teachClassList + "Name: " + getName() + "ID" + getID() +
                '}';
    }

    public Teacher(String name, String password) {//Ask leader if it wouldn't be better to put a string in Schedule classes
        super(name, password);
        teachClassList = new ArrayList<>();
    }

    public ArrayList<Class> getTeachClassList() {
        return teachClassList;
    }

    public void createClasses() {
        System.out.println("Insert the name of the class you want to create: ");
        String className = Ler.umaString();
        System.out.println("What is the maximum number of students for this class: ");
        int capacity = Ler.umInt();
        Class c = new Class(className, super.getName(), capacity);

        teachClassList.add(c);
    }

    public void askSheduleClass(ArrayList<User> users, ArrayList<Weekday> weekdays, ArrayList<Weekend> weekends) {
        int weekdayChoosen = -1;
        do{//Make case 0
            System.out.println("When do you want to schedule the class? ");
            System.out.println("0- Cancel");
            System.out.println("1- Monday");
            System.out.println("2- Tuesday");
            System.out.println("3- Wednesday");
            System.out.println("4- Thursday");
            System.out.println("5- Friday");
            System.out.println("6- Saturday");
            System.out.println("7- Sunday");
            weekdayChoosen = Ler.umInt();
        } while(weekdayChoosen<1 || weekdayChoosen>7);
        HashMap<Integer,Schedule> idsToSchedule;
        idsToSchedule= new HashMap<>(7);
        try {
            ObjectInputStream isSchedule = new ObjectInputStream(new FileInputStream(
                    "C:\\Users\\Lenovo\\Desktop\\Schedule.dat"));
            idsToSchedule = (HashMap<Integer, Schedule>) isSchedule.readObject();
        } catch (IOException e) {
            System.out.println(e.getMessage());
        } catch (ClassNotFoundException e) {
            System.out.println(e.getMessage());
        }
        if(idsToSchedule.get(weekdayChoosen) == null){
            if (weekdayChoosen >=1 && weekdayChoosen <=5){
                Weekday newDay = new Weekday(weekdayChoosen);
                idsToSchedule.put(weekdayChoosen, newDay);
                boolean found = true;
                int position = -1;
                do {

                    System.out.println("Escolha uma classe por ID :");
                    for (Class t : teachClassList) {
                        System.out.println("ID : " + t.getId() + "; Name: " + t.getName() + "; Capacity:" + t.getCapacity());
                    }
                    int choice = Ler.umInt();
                    for (int i = 0; i < teachClassList.size(); i++) {
                        if (choice == teachClassList.get(i).getId()) {
                            position = i;
                            found = false;
                        }
                    }

                } while (found);
                newDay.scheduleClass(teachClassList.get(position));//make a reader for classes
                idsToSchedule.put(weekdayChoosen,newDay);
                try {
                    ObjectOutputStream osSchedule = new ObjectOutputStream(new FileOutputStream("C:\\Users\\Lenovo\\Desktop\\Schedule.dat"));
                    osSchedule.writeObject(idsToSchedule);
                    osSchedule.flush();
                } catch(IOException e) {
                    System.out.println(e.getMessage());
                }
            }
            /*else{
                Ask leader what about weekend schedule
                Weekend newDay = new Weekend(weekdayChoosen);
                idsToSchedule.put(weekdayChoosen, newDay);
                boolean found = true;
                int position = -1;
                do {

                    System.out.println("Escolha uma classe por ID :");
                    for (Class t : teachClassList) {
                        System.out.println("ID : " + t.getId() + "; Name: " + t.getName() + "; Capacity:" + t.getCapacity());
                    }
                    int choice = Ler.umInt();
                    for (int i = 0; i < teachClassList.size(); i++) {
                        if (choice == teachClassList.get(i).getId()) {
                            position = i;
                            found = false;
                        }
                    }

                } while (found);
                newDay.scheduleClass(teachClassList.get(position));//make a reader for classes
                idsToSchedule.put(weekdayChoosen,newDay);
                try {
                    ObjectOutputStream osSchedule = new ObjectOutputStream(new FileOutputStream("C:\\Users\\Lenovo\\Desktop\\Schedule.dat"));
                    osSchedule.writeObject(idsToSchedule);
                    osSchedule.flush();
                } catch(IOException e) {
                    System.out.println(e.getMessage());
                }
            }*/
            }else {
            if(weekdayChoosen >=1 && weekdayChoosen<=5){
                boolean found = true;
                int position = -1;
                do {
                    System.out.println("Escolha uma classe por ID :");
                    for (Class t : teachClassList) {
                        System.out.println("ID : " + t.getId() + "; Name: " + t.getName() + "; Capacity:" + t.getCapacity());
                    }
                    int choice = Ler.umInt();
                    for (int i = 0; i < teachClassList.size(); i++) {
                        if (choice == teachClassList.get(i).getId()) {
                            position = i;
                            found = false;
                        }
                    }
                } while (found);
                idsToSchedule.get(weekdayChoosen).scheduleClass(teachClassList.get(position));//make a reader for classes

                try {
                    ObjectOutputStream osSchedule = new ObjectOutputStream(new FileOutputStream("C:\\Users\\Lenovo\\Desktop\\Schedule.dat"));
                    osSchedule.writeObject(idsToSchedule);
                    osSchedule.flush();
                } catch(IOException e) {
                    System.out.println(e.getMessage());
                }
            }
        }



        /*
         * ArrayList<Class> teachClassList = {"Yoga"(20), "Push ups"(15), "Sit ups"(30)}
         * 
         * Choose one of your classes:
         * 1- Yoga
         * 2- Push-ups
         * 3- Sit-ups
         */
        /*System.out.println("Choose one of your classes: ");
        for(int i=0; i<teachClassList.size(); i++) {
            int a = i+1;
            for(int j=0; j<teachClassList.size(); j++) {
                System.out.println(a + "- " + teachClassList.get(j).getName());
            }
        }
        System.out.println();*/

        // To create weekdays

        // To access weekdays
        /*if(weekdayChoosen==0) {
            return;
        } else if(weekdayChoosen >= 1 && weekdayChoosen <=5) {
            if(weekdays.size()<5) { // 5 max days for weekdays
                Weekday weekday = new Weekday();
            }
            for(int i=0; i<weekdays.size(); i++) {
                if(weekdays.get(i).getId() == weekdayChoosen) {
                    weekdays.get(i).scheduleClass(null);
                }
            }
           // weekdays.scheduleClass(c); ainda não está feito
        } else if(weekdayChoosen==6 || weekdayChoosen == 7) {

        } else {
            System.out.println("Invalid Input");
            askSheduleClass(users,weekdays,weekends);
        }*/
    }
    public int getID(){
        return super.getId();
    }

    public static void enterIDT(ArrayList<Teacher> myTeachers) {
        int answer = -1;
        do {
            answer = enterIDPrompt();
            if (answer != 0) {
                loginTeacher(myTeachers, answer);
            }
        } while (answer != 0);
    }
    public static int enterIDPrompt() {
        // nobody has ID = 0, that's why it's reserved for "Cancel"
        System.out.println("0- Cancel");
        System.out.println("Enter ID: ");
        int answer = Ler.umInt();
        return answer;
    }


    public static void loginTeacher(ArrayList<Teacher> myTeachers, int id) {
        boolean found = false;
        // guess from 0 to 9999 (guess has to be String, so 64 doesn't work, and you have
        // to type 0064 instead)
        for (int i = 0; i < myTeachers.size(); i++) {
            if (myTeachers.get(i).getId() == id) {
                found = true;
                String password = myTeachers.get(i).getPassword();
                //after the Teacher misses the guess three times, it comes back
                guessT(3, password, id, myTeachers);
            }
        }
        if (!found) {
            System.out.println("There is no teacher with that ID");

        } else {
            enterIDT(myTeachers);
        }
    }

    public static void guessT(int maxGuesses, String password, int id, ArrayList<Teacher> myTeachers) {
        String guess;
        int guessCount = 0;
        boolean outOfGuesses = false;
        /*
         * "guess == password" doesn't work because it only works for numbers.
         * For Strings, you must use "guess.equals(password)"
         */
        while (!outOfGuesses && guessCount < maxGuesses) {
            System.out.print("Enter password: ");
            guess = Ler.umaString();
            guessCount++;
            if (guess.equals(password))
                outOfGuesses = true;
        }
        if (outOfGuesses == true) {
            // o guess corresponde a password
            menuTeacher(myTeachers, id);
        } else {
            System.out.println("Try again");
        }
    }

    public static void menuTeacher(ArrayList<Teacher> myTeachers, int id) {
        int answer = 0;
        do {
            System.out.println("0- Logout");
            System.out.println("1- Check information");
            System.out.println("2- Check classes");
            answer = Ler.umInt();
            switch(answer) {
                case 1:
                    for (int i = 0; i < myTeachers.size(); i++) {
                        if (myTeachers.get(i).getId() == id) {
                            System.out.println(myTeachers.get(i));
                            break;
                        }
                    }
                case 0: break;
                default: System.out.println("Inserte un numero valido");
                    continue;
            }
        } while(answer != 0);
    }


}
