package JavaWork;
import java.util.*;

public class Lesson {
    private int id;
    private String name;
    private String teacher;
    // private ArrayList<Integer> horas;
    private ArrayList<User> usersInLesson;
    private int capacity;
    private int participants;
    private static int last = 0;
    
    public Lesson() {
    	name = "";
    }
    public Lesson(String name, String teacher, int capacity) {
        this.name = name;
        this.capacity = capacity;
        last++;
        id = last;
    }

    public int getId() {
        return id;
    }


    public String getName() {
        return name;
    }
    
    public String getTeacher() {
    	return teacher;
    }

    public int getCapacity() {
        return capacity;
    }

    public int getParticipants() {
        return participants;
    }

    public void setName(String name) {
        this.name = name;
    }
    
    public void setTeacher(String teacher) {
    	this.teacher = teacher;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public void setParticipants(int participants) {
        this.participants = participants;
    }

    public String toString() {
        return "Lesson Name = "  + getName() + "\ncapacity = " + capacity + "\nparticipants = " + participants ;
    }

    public void getReservationForLesson() {
        if(getParticipants()<getCapacity()) {
            participants++;
        } else {
            System.out.println("The class is full");
        }
    }

}
