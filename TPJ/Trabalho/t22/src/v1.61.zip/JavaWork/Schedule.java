package JavaWork;

abstract class Schedule {

    public abstract void scheduleLesson(Lesson c);

}

