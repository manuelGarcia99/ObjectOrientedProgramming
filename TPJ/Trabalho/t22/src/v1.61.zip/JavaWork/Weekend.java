package JavaWork;

public class Weekend  {//fazer esta classe 9am->2pm

    private int id;

    public Weekend(int id){
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

}
