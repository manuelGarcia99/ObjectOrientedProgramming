package JavaWork;
import java.util.*;
import java.io.*;

public class Sign_In {
    public static void menu(ArrayList<User> users, ArrayList<Teacher> teachers) {
        int answer = -1;
        do {
            answer = signInMenuPrompt();
            if(answer == 1) {
                Sign_In.insertUser(users);
            } else if(answer == 2) {

            } else if(answer != 0) {
                System.out.println("Invalid input, please try again.");

            }
        } while( answer != 0);
    }

    public static int signInMenuPrompt() {
        System.out.println("\n\nYou are on the sign-in menu");
        System.out.println("0- Cancel");
        System.out.println("1- User");
        System.out.println("2- Teacher");
        int answer = Ler.umInt();
        return answer;
    }

    public static void askUserOrAdm(ArrayList<User> myUsers) {
        System.out.println("1- User");
        System.out.println("2- Administrator");
        System.out.println("3- Go back");
        int answer = Ler.umInt();
        if(answer == 1) {
            insertUser(myUsers);
        } else if(answer == 2) {

        } else if(answer == 3) {
            
        } else {
            System.out.println("Invalid Input");
            askUserOrAdm(myUsers);
        }
    }

    public static void insertTeacher(ArrayList<Teacher> teachers) {
        System.out.println("What is your name? ");
        String name = Ler.umaString();
        String password= insertPassword();
        Teacher l = new Teacher(name, password);
        teachers.add(l);
        try {
            ObjectOutputStream os = new ObjectOutputStream(new FileOutputStream("C:\\Users\\manec\\Desktop\\Teacher.dat"));
            os.writeInt(Teacher.getLast());
            os.writeObject(teachers);
            os.flush();
        } catch(IOException e) {
            System.out.println(e.getMessage());
        }
        System.out.println("Your new ID is : " + (User.getLast() +1));
    }

    public static void insertUser(ArrayList<User> users) {
        System.out.println("What is your name? ");
        String name = Ler.umaString();
        String password= insertPassword();
        User l = new User(name,password);
        users.add(l);
        try {
            ObjectOutputStream os = new ObjectOutputStream(new FileOutputStream("C:\\Users\\manec\\Desktop\\User.dat"));
            os.writeInt(User.getLast());
            os.writeObject(users);
            os.flush();
        } catch(IOException e) {
            System.out.println(e.getMessage());
        }
        System.out.println("Your new ID is : " + (User.getLast() +1));
    }

    public static String insertPassword(){
        System.out.println("Create a PIN of 4 digits:");
        String password = "";
        String password2 = "";
        boolean check = false;
        do {
            password = Ler.umaString();
            if(!checkPin(password)){
                continue;
            }
            System.out.println("Please confirm the PIN");
            password2 = Ler.umaString();
            if(password.equals(password)){
                break;
            }
            else {
                System.out.println("The two PINs don't match please try again!");
            }
        } while (!check);
        if(password.equals(password2) && checkPin(password) && checkPin(password2)){
            return password;
        }

        return insertPassword();

    }

    public static boolean checkPin(String pin) {
        boolean allDigits = false;
        if (pin.length() != 4) {
            System.out.println("You have not entered a 4-digit pin");
        } else {
            allDigits = true;
            for (int i = 0; i < 4; i++) {
                if (!Character.isDigit(pin.charAt(i))) {
                    allDigits = false;
                    break; // break gets you out of the for cycle
                }
            }
        }
        if (allDigits) {
            return true;
        } else {
            System.out.println("Enter a number");
            return false;
        }
    }
}
