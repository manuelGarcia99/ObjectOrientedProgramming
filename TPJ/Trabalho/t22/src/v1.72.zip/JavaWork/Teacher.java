package JavaWork;

import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;

public class Teacher extends User {
    private ArrayList<Lesson> teachLessonList; // list of lessons that the teacher teaches

    @Override
    public String toString() {
        return "Teacher{" +
                "teachLessonList=" + teachLessonList + "Name: " + getName() + "ID" + getID() +
                '}';
    }

    public Teacher(String name, String password) {//Ask leader if it wouldn't be better to put a string in Schedule lessons
        super(name, password);
        teachLessonList = new ArrayList<>();
    }
    public static void insert(ArrayList<User> users, ArrayList<Teacher> teachers) {
        System.out.println("What is your name? ");
        String name = Ler.umaString();
        String password= Sign_In.insertPassword();
        Teacher l = new Teacher(name, password);
        teachers.add(l);
        try {
            ObjectOutputStream os = new ObjectOutputStream(new FileOutputStream("C:\\Users\\manec\\Desktop\\Teacher.dat"));
            os.writeInt(Teacher.getLast());
            os.writeObject(teachers);
            os.flush();
        } catch(IOException e) {
            System.out.println(e.getMessage());
        }
        users.add(l);
        try {
            ObjectOutputStream os = new ObjectOutputStream(new FileOutputStream("C:\\Users\\manec\\Desktop\\User.dat"));
            os.writeInt(User.getLast());
            os.writeObject(users);
            os.flush();
        } catch(IOException e) {
            System.out.println(e.getMessage());
        }
        System.out.println("Your new ID is: " + (User.getLast() +1));
    }

    public ArrayList<Lesson> getTeachLessonList() {
        return teachLessonList;
    }

    public void createLessons(ArrayList<Lesson> list) {
        System.out.println("Insert the name of the lesson you want to create: ");
        String lessonName = Ler.umaString();
        System.out.println("What is the maximum number of students for this lesson: ");
        int capacity = Ler.umInt();
        Lesson c = new Lesson(lessonName, getName(), capacity);
        try {
            ObjectOutputStream os = new ObjectOutputStream(new FileOutputStream("C:\\Users\\manec\\Desktop\\Lesson.dat"));
            os.writeInt(Lesson.getLast());
            os.writeObject(list);
            os.flush();
        } catch(IOException e) {
            System.out.println(e.getMessage());
        }

        teachLessonList.add(c);
    }

    public void askSheduleLesson(ArrayList<User> users, ArrayList<Weekday> weekdays, ArrayList<Weekend> weekends) {
        int weekdayChoosen = -1;
        do{//Make case 0
            System.out.println("When do you want to schedule the lesson? ");
            System.out.println("0- Cancel");
            System.out.println("1- Monday");
            System.out.println("2- Tuesday");
            System.out.println("3- Wednesday");
            System.out.println("4- Thursday");
            System.out.println("5- Friday");
            System.out.println("6- Saturday");
            System.out.println("7- Sunday");
            weekdayChoosen = Ler.umInt();
        } while(weekdayChoosen<1 || weekdayChoosen>7);
        HashMap<Integer,Schedule> idsToSchedule;
        idsToSchedule= new HashMap<>(7);
        try {
            ObjectInputStream isSchedule = new ObjectInputStream(new FileInputStream(
                    "C:\\Users\\manec\\Desktop\\Schedule.dat"));
            idsToSchedule = (HashMap<Integer, Schedule>) isSchedule.readObject();
        } catch (IOException e) {
            System.out.println(e.getMessage());
        } catch (ClassNotFoundException e) {
            System.out.println(e.getMessage());
        }
        if(idsToSchedule.get(weekdayChoosen) == null){
            if (weekdayChoosen >=1 && weekdayChoosen <=5){
                Weekday newDay = new Weekday(weekdayChoosen);
                idsToSchedule.put(weekdayChoosen, newDay);
                boolean found = true;
                int position = -1;
                do {

                    System.out.println("Choose a lesson by ID :");
                    for (Lesson t : teachLessonList) {
                        System.out.println("ID : " + t.getId() + "; Name: " + t.getName() + "; Capacity:" + t.getCapacity());
                    }
                    int choice = Ler.umInt();
                    for (int i = 0; i < teachLessonList.size(); i++) {
                        if (choice == teachLessonList.get(i).getId()) {
                            position = i;
                            found = false;
                        }
                    }

                } while (found);
                newDay.scheduleLesson(teachLessonList.get(position));//make a reader for lessons
                idsToSchedule.put(weekdayChoosen,newDay);
                try {
                    ObjectOutputStream osSchedule = new ObjectOutputStream(new FileOutputStream("C:\\Users\\Lenovo\\Desktop\\Schedule.dat"));
                    osSchedule.writeObject(idsToSchedule);
                    osSchedule.flush();
                } catch(IOException e) {
                    System.out.println(e.getMessage());
                }
            }
            /*else{
                Ask leader what about weekend schedule
                Weekend newDay = new Weekend(weekdayChoosen);
                idsToSchedule.put(weekdayChoosen, newDay);
                boolean found = true;
                int position = -1;
                do {

                    System.out.println("Escolha uma lesson por ID :");
                    for (Lesson t : teachLessonList) {
                        System.out.println("ID : " + t.getId() + "; Name: " + t.getName() + "; Capacity:" + t.getCapacity());
                    }
                    int choice = Ler.umInt();
                    for (int i = 0; i < teachLessonList.size(); i++) {
                        if (choice == teachLessonList.get(i).getId()) {
                            position = i;
                            found = false;
                        }
                    }

                } while (found);
                newDay.scheduleLesson(teachLessonList.get(position));//make a reader for lesson
                idsToSchedule.put(weekdayChoosen,newDay);
                try {
                    ObjectOutputStream osSchedule = new ObjectOutputStream(new FileOutputStream("C:\\Users\\Lenovo\\Desktop\\Schedule.dat"));
                    osSchedule.writeObject(idsToSchedule);
                    osSchedule.flush();
                } catch(IOException e) {
                    System.out.println(e.getMessage());
                }
            }*/
            }else {
            if(weekdayChoosen >=1 && weekdayChoosen<=5){
                boolean found = true;
                int position = -1;
                do {
                    System.out.println("Escolha uma lesson por ID :");
                    for (Lesson t : teachLessonList) {
                        System.out.println("ID : " + t.getId() + "; Name: " + t.getName() + "; Capacity:" + t.getCapacity());
                    }
                    int choice = Ler.umInt();
                    for (int i = 0; i < teachLessonList.size(); i++) {
                        if (choice == teachLessonList.get(i).getId()) {
                            position = i;
                            found = false;
                        }
                    }
                } while (found);
                idsToSchedule.get(weekdayChoosen).scheduleLesson(teachLessonList.get(position));//make a reader for lessons

                try {
                    ObjectOutputStream osSchedule = new ObjectOutputStream(new FileOutputStream("C:\\Users\\Lenovo\\Desktop\\Schedule.dat"));
                    osSchedule.writeObject(idsToSchedule);
                    osSchedule.flush();
                } catch(IOException e) {
                    System.out.println(e.getMessage());
                }
            }
        }



        /*
         * ArrayList<Lesson> teachLessonList = {"Yoga"(20), "Push ups"(15), "Sit ups"(30)}
         * 
         * Choose one of your lessons:
         * 1- Yoga
         * 2- Push-ups
         * 3- Sit-ups
         */
        /*System.out.println("Choose one of your lessons: ");
        for(int i=0; i<teachLessonList.size(); i++) {
            int a = i+1;
            for(int j=0; j<teachLessonList.size(); j++) {
                System.out.println(a + "- " + teachLessonList.get(j).getName());
            }
        }
        System.out.println();*/

        // To create weekdays

        // To access weekdays
        /*if(weekdayChoosen==0) {
            return;
        } else if(weekdayChoosen >= 1 && weekdayChoosen <=5) {
            if(weekdays.size()<5) { // 5 max days for weekdays
                Weekday weekday = new Weekday();
            }
            for(int i=0; i<weekdays.size(); i++) {
                if(weekdays.get(i).getId() == weekdayChoosen) {
                    weekdays.get(i).scheduleLesson(null);
                }
            }
           // weekdays.scheduleLesson(c); ainda não está feito
        } else if(weekdayChoosen==6 || weekdayChoosen == 7) {

        } else {
            System.out.println("Invalid Input");
            askSheduleLesson(users,weekdays,weekends);
        }*/
    }
    public int getID(){
        return super.getId();
    }

    public static void enterIDT(ArrayList<Teacher> teachers, ArrayList<Lesson> lessons) {
        int answer = -1;
        do {
            answer = enterIDPrompt();
            if (answer != 0) {
                login(teachers, answer, lessons);
            }
        } while (answer != 0);
    }
    public static int enterIDPrompt() {
        // nobody has ID = 0, that's why it's reserved for "Cancel"
        System.out.println("0- Cancel");
        System.out.println("Enter ID: ");
        int answer = Ler.umInt();
        return answer;
    }


    public static void login(ArrayList<Teacher> teachers, int id, ArrayList<Lesson> lessons) {
        boolean found = false;
        // guess from 0 to 9999 (guess has to be String, so 64 doesn't work, and you have
        // to type 0064 instead)
        for (int i = 0; i < teachers.size(); i++) {
            if (teachers.get(i).getId() == id) {
                found = true;
                String password = teachers.get(i).getPassword();
                //after the Teacher misses the guess three times, it comes back
                guessT(3, password, id, teachers, lessons);
            }
        }
        if (!found) {
            System.out.println("There is no teacher with that ID");
        } else {
            enterIDT(teachers, lessons);
        }
    }

    public static void guessT(int maxGuesses, String password, int id, ArrayList<Teacher> teachers, ArrayList<Lesson> lessons) {
        String guess;
        int guessCount = 0;
        boolean outOfGuesses = false;
        /*
         * "guess == password" doesn't work because it only works for numbers.
         * For Strings, you must use "guess.equals(password)"
         */
        while (!outOfGuesses && guessCount < maxGuesses) {
            System.out.print("Enter password: ");
            guess = Ler.umaString();
            guessCount++;
            if (guess.equals(password))
                outOfGuesses = true;
        }
        if (outOfGuesses == true) {
            // o guess corresponde a password
            menu(teachers, id, lessons);
        } else {
            System.out.println("Try again");
        }
    }

    public static void menu(ArrayList<Teacher> teachers, int id, ArrayList<Lesson> lessons) {//**//
        int answer = 0;
        do {
            System.out.println("0- Logout");
            System.out.println("1- Check information about myself");
            System.out.println("2- Check my lessons");
            System.out.println("3- Check my students");
            System.out.println("4- Create lesson");
            System.out.println("5- Choose schedule for a lesson");
            answer = Ler.umInt();
            switch(answer) {
                case 1:
                    for (int i = 0; i < teachers.size(); i++) {
                        if (teachers.get(i).getId() == id) {
                            System.out.println(teachers.get(i));
                            break;
                        }
                    }
                    break;
                case 2:
                    for (int i = 0; i< teachers.size(); i++)
                    {
                        if(teachers.get(i).getID() == id){
                            System.out.println(teachers.get(i).teachLessonList);
                            break;
                        }
                    }
                    break;
                case 4:
                    for(int i = 0; i< teachers.size(); i++){
                        if(teachers.get(i).getID() == id){
                            teachers.get(i).createLessons(lessons);
                            break;
                        }
                    }
                    break;
                case 5:
                    System.out.println("Choose the lesson: ");
                    for (int i = 0; i< teachers.size(); i++)
                    {
                        if(teachers.get(i).getID() == id){
                            for(int j =0 ; j<teachers.get(i).teachLessonList.size(); j++){
                                System.out.println(teachers.get(i).teachLessonList.get(j).getId() + ": " +teachers.get(i).teachLessonList.get(j));    
                            }

                            break;
                        }
                    }
                    break;
                case 0: break;
                default: System.out.println("Insert a valid number");
                    continue;
            }
        } while(answer != 0);
    }





}
