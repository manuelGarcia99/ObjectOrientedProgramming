package JavaWork;

import java.util.ArrayList;
import java.io.*;

public class User implements Serializable {
    private int id;
    private String name;
    private String password;
    private ArrayList<Lesson> assignedLessons;
    private static int last = 0;
    public User(String name, String password) {
        last++;
        id = last;
        this.name = name;
        this.password = password;
        assignedLessons = new ArrayList<Lesson>();
    }

    public int getId() {
        return id;
    }

    public static void setLast(int last) {
        User.last = last;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public String toString() {
        return "\nUser{" + "id=" + id + ", name=" + name + "}";
    }

    public static int getLast() {
        return last;
    }

    public boolean equals(Object obj) {
        if (obj != null && this.getClass() == obj.getClass()) {
            User e = (User) obj;
            return (this.id == e.id && this.name.equals(e.name));
        }
        return false;
    }

    public Object clone() {
        User copy = new User(name,password);
        return copy;
    }

    public static void enterID(ArrayList<User> users, ArrayList<Lesson> lessons) {
        int answer = -1;
        do {
            answer = enterIDPrompt();
            if (answer != 0) {
                loginUser(users, answer);
            }
        } while (answer != 0);
    }

    public static int enterIDPrompt() {
        // nobody has ID = 0, that's why it's reserved for "Cancel"
        System.out.println("0- Cancel");
        System.out.println("Enter ID: ");
        int answer = Ler.umInt();
        return answer;
    }


    public static void loginUser(ArrayList<User> users, int id) {
        boolean found = false;
        // guess from 0 to 9999 (guess has to be String, so 64 doesn't work, and you have
        // to type 0064 instead)
        for (int i = 0; i < users.size(); i++) {
            if (users.get(i).getId() == id) {
                found = true;
                String password = users.get(i).getPassword();
                //after the user misses the guess three times, it comes back
                guess(3, password, id, users);
            }
        }
        if (!found) {
            System.out.println("There is no User with that ID");

        }
    }

    public static void guess(int maxGuesses, String password, int id, ArrayList<User> users) {
        String guess;
        int guessCount = 0;
        boolean outOfGuesses = false;
        /*
         * "guess == password" doesn't work because it only works for numbers.
         * For Strings, you must use "guess.equals(password)"
         */
        while (!outOfGuesses && guessCount < maxGuesses) {
            System.out.print("Enter password: ");
            guess = Ler.umaString();
            guessCount++;
            if (guess.equals(password))
                outOfGuesses = true;
        }
        if (outOfGuesses == true) {
            // o guess corresponde a password
            menuUser(users, id);
        } else {
            System.out.println("Try again");
        }
    }

    public static void menuUser(ArrayList<User> users, int id) {
        int answer = 0;
        do {
            System.out.println("0- Logout");
            System.out.println("1- Check information");
            System.out.println("2- Check lessons");
            answer = Ler.umInt();
            switch(answer) {
                case 1:
                    for (int i = 0; i < users.size(); i++) {
                        if (users.get(i).getId() == id) {
                            System.out.println(users.get(i));
                            break;
                        }
                    }
                case 0: break;
                default: System.out.println("Insert a valid number");
                    continue;
            }
        } while(answer != 0);
    }

    public static void insert(ArrayList<User> users) {
        System.out.println("What is your name? ");
        String name = Ler.umaString();
        String password= Sign_In.insertPassword();
        User l = new User(name,password);
        users.add(l);
        try {
            ObjectOutputStream os = new ObjectOutputStream(new FileOutputStream("C:\\Users\\manec\\Desktop\\User.dat"));
            os.writeInt(User.getLast());
            os.writeObject(users);
            os.flush();
        } catch(IOException e) {
            System.out.println(e.getMessage());
        }
        System.out.println("Your new ID is : " + (User.getLast() ));
    }
}
