package JavaWork;
import java.io.Serializable;
import java.util.*;

public class Lesson implements Serializable {
    private int id;
    private String name;
    private String teacher;

    private int teacherId;
    // private ArrayList<Integer> horas;
    private ArrayList<User> usersInLesson;
    private int capacity;
    private int participants;



    public static void setLast(int last) {
        Lesson.last = last;
    }

    private static int last = 0;


    public static int getLast() {
        return last;
    }

    public int getTeacherId() {
        return teacherId;
    }

    public void setTeacherId(int teacherId) {
        this.teacherId = teacherId;
    }

    public Lesson(String name, String teacher, int capacity, int teacherId) {
        this.name = name;
        this.capacity = capacity;
        last++;
        id = last;
        this.teacher = teacher;

        //writeIfDifferent(); use always when creating a new class
    }

    public int getId() {
        return id;
    }


    public String getName() {
        return name;
    }
    
    public String getTeacher() {
    	return teacher;
    }

    public int getCapacity() {
        return capacity;
    }

    public int getParticipants() {
        return participants;
    }

    public void setName(String name) {
        this.name = name;
    }
    
    public void setTeacher(String teacher) {
    	this.teacher = teacher;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public void setParticipants(int participants) {
        this.participants = participants;
    }

    public String toString() {
        return "Lesson Name = "  + name + "\ncapacity = " + capacity + "\nparticipants = " + participants ;
    }

    public void getReservationForLesson() {
        if(getParticipants()<getCapacity()) {
            participants++;
        } else {
            System.out.println("The lesson is full");
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Lesson lesson = (Lesson) o;
        return capacity == lesson.capacity && participants == lesson.participants && name.equals(lesson.name) && teacher.equals(lesson.teacher);
    }

}
