package JavaWork;

import java.io.Serializable;

abstract class Schedule implements Serializable {

    public abstract void scheduleLesson(Lesson c);

}

