package Ficha7;

public class Teste {
    public static void main(String[] args){

    }
}
